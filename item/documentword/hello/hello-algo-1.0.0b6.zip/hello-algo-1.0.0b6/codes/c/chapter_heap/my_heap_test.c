/**
 * File: my_heap_test.c
 * Created Time: 2023-01-15
 * Author: Reanon (793584285@qq.com)
 */

#include "my_heap.c"

/* Driver Code */
int main() {
    /* 初始化堆 */
    // 初始化大顶堆
    int nums[] = {9, 8, 6, 6, 7, 5, 2, 1, 4, 3, 6, 2};
    MaxHeap *heap = newMaxHeap(nums, sizeof(nums) / sizeof(int));
    printf("输入数组并建堆后\n");
    printHeap(heap->data, heap->size);

    /* 获取堆顶元素 */
    printf("\n堆顶元素为 %d\n", peek(heap));

    /* 元素入堆 */
    push(heap, 7);
    printf("\n元素 7 入堆后\n");
    printHeap(heap->data, heap->size);

    /* 堆顶元素出堆 */
    int top = pop(heap);
    printf("\n堆顶元素 %d 出堆后\n", top);
    printHeap(heap->data, heap->size);

    /* 获取堆大小 */
    printf("\n堆元素数量为 %d\n", size(heap));

    /* 判断堆是否为空 */
    printf("\n堆是否为空 %d\n", isEmpty(heap));

    // 释放内存
    freeMaxHeap(heap);

    return 0;
}
